export interface Coupon {
  id: string;
  name: string;
  discount: number;
}