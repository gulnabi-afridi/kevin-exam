"use client";

const Home = () => {
  return <span>Home</span>;
};

export default Home;
