"use client";

import AddCoupon from "@components/addCoupon";
import Cart from "@components/cart";

const ViewCart = () => {
  return (
    <>
      <Cart></Cart> // onClose isnt configured yet
      <AddCoupon />
    </>
  );
};

export default ViewCart;
